<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SallaController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/


Route::get('/token', [SallaController::class, 'token']);
Route::get('/refreshtoken', [SallaController::class, 'refreshtoken']);
Route::post('/updates', [SallaController::class, 'updates']);
Route::any('/callback', [SallaController::class, 'callback']);
Route::any('/storii', [SallaController::class, 'storii']);
Route::any('/statuslist', [SallaController::class, 'statuslist']);
Route::any('/customers', [SallaController::class, 'customers']);
Route::any('/events', [SallaController::class, 'events']);