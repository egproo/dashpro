<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('email')->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->rememberToken();
            $table->timestamps();
        });
		
    // جدول تخزين بيانات المتجر
	Schema::create('stores', function (Blueprint $table) {
		$table->bigIncrements('id');
		$table->unsignedBigInteger('salla_id')->unique();
		$table->string('code')->nullable();
		$table->string('state')->nullable();
		$table->string('name');
		$table->string('entity');
		$table->string('email');
		$table->string('avatar')->nullable();
		$table->string('plan');
		$table->string('status');
		$table->boolean('verified');
		$table->string('currency');
		$table->string('domain');
		$table->text('description')->nullable();
		$table->json('licenses')->nullable();
		$table->json('social')->nullable();
		$table->timestamps();
	});	
Schema::create('store_tokens', function (Blueprint $table) {
    $table->bigIncrements('id');
    $table->unsignedBigInteger('store_id');
    $table->foreign('store_id')->references('id')->on('stores');
    $table->text('access_token');
    $table->text('refresh_token');
    $table->unsignedBigInteger('expires_in');
    $table->string('token_type');
    $table->text('scope');
    $table->timestamps();
});	
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
		Schema::dropIfExists('store_tokens');
		Schema::dropIfExists('stores');	
		Schema::dropIfExists('users');	

    }
};
