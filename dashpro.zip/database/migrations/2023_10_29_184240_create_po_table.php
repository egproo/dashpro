<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePoTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('customer_groups', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('salla_id')->unique();
            $table->unsignedBigInteger('store_id');
            $table->string('name');
            $table->json('conditions')->nullable();
            $table->timestamps();
        });
        Schema::create('customers', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('salla_id')->unique();
            $table->unsignedBigInteger('store_id');
            $table->string('first_name');
            $table->string('last_name');
            $table->bigInteger('mobile');
            $table->string('mobile_code');
            $table->string('email')->unique();
            $table->string('avatar')->nullable();
            $table->enum('gender', ['male', 'female'])->nullable();
            $table->date('birthday')->nullable();
            $table->string('city')->nullable();
            $table->string('country')->nullable();
            $table->string('country_code')->nullable();
            $table->string('currency')->nullable();
            $table->string('location')->nullable();
            $table->timestamps();
        });	
Schema::create('categories', function (Blueprint $table) {
    $table->bigIncrements('id');
    $table->unsignedBigInteger('salla_id')->unique();
    $table->unsignedBigInteger('store_id');
    $table->string('name');
    $table->text('description')->nullable();
    $table->timestamps();
    
    $table->foreign('store_id')->references('id')->on('stores');
});		
        // جدول المنتجات
        Schema::create('products', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('salla_id')->unique();
            $table->unsignedBigInteger('store_id');
            $table->string('name');
            $table->string('type');
            $table->string('sku')->nullable();
            $table->decimal('price', 8, 2);
            $table->decimal('discount_price', 8, 2)->nullable();
            $table->text('description')->nullable();
            $table->unsignedBigInteger('category_id');
            $table->integer('stock_quantity');
            $table->enum('status', ['active', 'inactive']);
            $table->timestamps();
            $table->foreign('category_id')->references('id')->on('categories');
            $table->foreign('store_id')->references('id')->on('stores');
        });

        // جدول الإصدارات المختلفة للمنتجات
        Schema::create('product_variants', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('product_id');
            $table->string('name');
            $table->string('sku')->nullable();
            $table->decimal('price', 8, 2);
            $table->decimal('discount_price', 8, 2)->nullable();
            $table->integer('stock_quantity');
            $table->timestamps();
            
            $table->foreign('product_id')->references('id')->on('products');
        });

        // جدول خيارات المنتج
        Schema::create('product_options', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('product_id');
            $table->string('name');
            $table->string('type');  // مثل: color, size, etc.
            $table->timestamps();
            
            $table->foreign('product_id')->references('id')->on('products');
        });

        // جدول قيم خيارات المنتج
        Schema::create('product_option_values', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('product_option_id');
            $table->string('name');
            $table->decimal('price', 8, 2)->nullable();  // قد يكون هناك سعر إضافي لبعض الخيارات
            $table->timestamps();
            
            $table->foreign('product_option_id')->references('id')->on('product_options');
        });
	// جدول صور المنتج
        Schema::create('product_images', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('product_id');
            $table->string('image_path');
            $table->string('alt_text')->nullable();
            $table->timestamps();
            
            $table->foreign('product_id')->references('id')->on('products');
        });
        // جدول حالات الطلب
        Schema::create('order_statuses', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('salla_id')->unique();
            $table->string('name');
            $table->string('color');
            $table->string('icon');
            $table->timestamps();
        });
	// جدول الطلبات
        Schema::create('orders', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('salla_id')->unique();
            $table->unsignedBigInteger('store_id');
            $table->unsignedBigInteger('customer_id');
            $table->unsignedBigInteger('status_id');
            $table->decimal('total_price', 8, 2);
            $table->decimal('shipping_cost', 8, 2);
            $table->string('payment_method');
            $table->string('shipping_method');
            $table->timestamp('order_date')->nullable();
            $table->timestamps();
            
            $table->foreign('store_id')->references('id')->on('stores');
            $table->foreign('customer_id')->references('id')->on('customers');
            $table->foreign('status_id')->references('id')->on('order_statuses');
        });

	// جدول عناصر الطلب
        Schema::create('order_items', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('order_id');
            $table->unsignedBigInteger('product_id');
            $table->integer('quantity');
            $table->decimal('price', 8, 2);
            $table->timestamps();
            
            $table->foreign('order_id')->references('id')->on('orders');
            $table->foreign('product_id')->references('id')->on('products');
        });



// جدول تاريخ الطلبات
Schema::create('order_history', function (Blueprint $table) {
    $table->bigIncrements('id');
    $table->unsignedBigInteger('order_id');
    $table->unsignedBigInteger('status_id');
    $table->text('comment')->nullable(); // تعليق أو ملاحظة حول التغيير
    $table->timestamp('changed_at')->useCurrent(); // وقت التغيير
    $table->timestamps();
    
    $table->foreign('order_id')->references('id')->on('orders');
    $table->foreign('status_id')->references('id')->on('order_statuses');
});


        // جدول وسائل الدفع للطلب
        Schema::create('order_payments', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('order_id');
            $table->string('payment_method');
            $table->decimal('amount', 8, 2);
            $table->timestamp('payment_date')->nullable();
            $table->timestamps();
            
            $table->foreign('order_id')->references('id')->on('orders');
        });

        // جدول شحنات الطلب
        Schema::create('order_shipments', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('order_id');
            $table->string('shipment_method');
            $table->string('tracking_number')->nullable();
            $table->timestamp('shipment_date')->nullable();
            $table->timestamps();
            
            $table->foreign('order_id')->references('id')->on('orders');
        });

        // جدول وسوم الطلب
        Schema::create('order_tags', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('salla_id')->unique();
            $table->string('name');
            $table->timestamps();
        });
		
		
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('order_tags');
        Schema::dropIfExists('order_shipments');
        Schema::dropIfExists('order_payments');
        Schema::dropIfExists('order_history');
        Schema::dropIfExists('order_items');
        Schema::dropIfExists('orders');
        Schema::dropIfExists('order_statuses');		
        Schema::dropIfExists('product_images');
        Schema::dropIfExists('product_option_values');
        Schema::dropIfExists('product_options');
        Schema::dropIfExists('product_variants');
        Schema::dropIfExists('products');
        Schema::dropIfExists('categories');
        Schema::dropIfExists('customers');
        Schema::dropIfExists('customer_groups');
		
    }
}
