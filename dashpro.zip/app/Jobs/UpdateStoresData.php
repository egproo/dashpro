<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use App\Models\Store;
use App\Models\StoreToken;
use App\Models\Category;

class UpdateStoresData implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        // Get all stores
        $stores = Store::all();

        foreach ($stores as $store) {
            // Get the store's token
            $token = StoreToken::where('store_id', $store->id)->first();

            if (!$token) {
                // If there's no token for this store, skip to the next iteration
                continue;
            }

            // Fetch categories for this store
            $categories = $this->fetchCategoriesFromSalla($token->access_token);

            // Process and save the categories
            foreach ($categories as $categoryData) {
                $this->saveCategory($categoryData, $store->id);
            }

            // You can add more logic here to fetch and save other data like products, orders, etc.
        }
    }

    /**
     * Fetch categories from Salla API.
     *
     * @param string $accessToken
     * @return array
     */
    protected function fetchCategoriesFromSalla(string $accessToken): array
    {
        $curl = curl_init();

        curl_setopt_array($curl, [
            CURLOPT_URL => "https://api.salla.dev/admin/v2/categories",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                "Accept: application/json",
                "Authorization: Bearer " . $accessToken
            ],
        ]);

        $response = curl_exec($curl);
        curl_close($curl);

        $data = json_decode($response, true);

        return $data['data'] ?? [];
    }

    /**
     * Save category to the database.
     *
     * @param array $categoryData
     * @param int $storeId
     */
    protected function saveCategory(array $categoryData, int $storeId): void
    {
        Category::updateOrCreate(
            ['salla_id' => $categoryData['id'], 'store_id' => $storeId],
            [
                'name' => $categoryData['name'],
                'sort_order' => $categoryData['sort_order'],
                'status' => $categoryData['status'],
                // Add other fields here as needed
            ]
        );
    }


}
