<?php

namespace App\Models;

use App\Models\Base\Customer as BaseCustomer;

class Customer extends BaseCustomer
{
	protected $fillable = [
		'salla_id',
		'store_id',
		'first_name',
		'last_name',
		'mobile',
		'mobile_code',
		'email',
		'avatar',
		'gender',
		'birthday',
		'city',
		'country',
		'country_code',
		'currency',
		'location'
	];

public function groups()
{
    return $this->belongsToMany(CustomerGroup::class, 'customer_group_customer');
}
	
}
