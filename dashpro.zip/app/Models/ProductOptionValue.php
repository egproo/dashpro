<?php

namespace App\Models;

use App\Models\Base\ProductOptionValue as BaseProductOptionValue;

class ProductOptionValue extends BaseProductOptionValue
{
	protected $fillable = [
		'product_option_id',
		'name',
		'price'
	];
}
