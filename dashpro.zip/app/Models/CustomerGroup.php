<?php

namespace App\Models;

use App\Models\Base\CustomerGroup as BaseCustomerGroup;

class CustomerGroup extends BaseCustomerGroup
{
	protected $fillable = [
		'salla_id',
		'store_id',
		'name',
		'conditions'
	];
}
