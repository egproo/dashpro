<?php

namespace App\Models;

use App\Models\Base\OrderShipment as BaseOrderShipment;

class OrderShipment extends BaseOrderShipment
{
	protected $fillable = [
		'order_id',
		'shipment_method',
		'tracking_number',
		'shipment_date'
	];
}
