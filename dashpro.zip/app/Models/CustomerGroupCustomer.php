<?php

namespace App\Models;

use App\Models\Base\CustomerGroupCustomer as BaseCustomerGroupCustomer;

class CustomerGroupCustomer extends BaseCustomerGroupCustomer
{
	protected $fillable = [
		'customer_id',
		'customer_group_id'
	];
}
