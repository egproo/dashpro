<?php

namespace App\Models;

use App\Models\Base\OrderTag as BaseOrderTag;

class OrderTag extends BaseOrderTag
{
	protected $fillable = [
		'salla_id',
		'name'
	];
}
