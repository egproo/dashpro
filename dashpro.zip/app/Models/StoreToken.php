<?php

namespace App\Models;

use App\Models\Base\StoreToken as BaseStoreToken;

class StoreToken extends BaseStoreToken
{
	protected $hidden = [
		'access_token',
		'refresh_token'
	];

	protected $fillable = [
		'store_id',
		'access_token',
		'refresh_token',
		'expires_in',
		'token_type',
		'scope'
	];
}
