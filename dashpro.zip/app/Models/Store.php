<?php

namespace App\Models;

use App\Models\Base\Store as BaseStore;

class Store extends BaseStore
{
	protected $fillable = [
		'salla_id',
		'code',
		'state',
		'name',
		'entity',
		'email',
		'avatar',
		'plan',
		'status',
		'verified',
		'currency',
		'domain',
		'description',
		'licenses',
		'social'
	];
}
