<?php

namespace App\Models;

use App\Models\Base\Order as BaseOrder;

class Order extends BaseOrder
{
	protected $fillable = [
		'salla_id',
		'store_id',
		'customer_id',
		'status_id',
		'total_price',
		'shipping_cost',
		'payment_method',
		'shipping_method',
		'order_date'
	];
}
