<?php

namespace App\Models;

use App\Models\Base\Product as BaseProduct;

class Product extends BaseProduct
{
	protected $fillable = [
		'salla_id',
		'store_id',
		'name',
		'type',
		'sku',
		'price',
		'discount_price',
		'description',
		'category_id',
		'stock_quantity',
		'status'
	];
}
