<?php

namespace App\Models;

use App\Models\Base\TokenHistory as BaseTokenHistory;

class TokenHistory extends BaseTokenHistory
{
	protected $hidden = [
		'access_token',
		'refresh_token'
	];

	protected $fillable = [
		'store_id',
		'access_token',
		'refresh_token'
	];
}
