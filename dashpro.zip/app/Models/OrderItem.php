<?php

namespace App\Models;

use App\Models\Base\OrderItem as BaseOrderItem;

class OrderItem extends BaseOrderItem
{
	protected $fillable = [
		'order_id',
		'product_id',
		'quantity',
		'price'
	];
}
