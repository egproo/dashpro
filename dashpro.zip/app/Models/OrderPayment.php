<?php

namespace App\Models;

use App\Models\Base\OrderPayment as BaseOrderPayment;

class OrderPayment extends BaseOrderPayment
{
	protected $fillable = [
		'order_id',
		'payment_method',
		'amount',
		'payment_date'
	];
}
