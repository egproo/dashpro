<?php

namespace App\Models;

use App\Models\Base\OrderHistory as BaseOrderHistory;

class OrderHistory extends BaseOrderHistory
{
	protected $fillable = [
		'order_id',
		'status_id',
		'comment',
		'changed_at'
	];
}
