<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\Base;

use App\Models\Store;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * Class TokenHistory
 * 
 * @property int $id
 * @property int $store_id
 * @property string $access_token
 * @property string $refresh_token
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * 
 * @property Store $store
 *
 * @package App\Models\Base
 */
class TokenHistory extends Model
{
	protected $table = 'token_history';

	protected $casts = [
		'store_id' => 'int'
	];

	public function store()
	{
		return $this->belongsTo(Store::class);
	}
}
