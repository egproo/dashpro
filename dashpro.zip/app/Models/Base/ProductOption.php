<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\Base;

use App\Models\Product;
use App\Models\ProductOptionValue;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;

/**
 * Class ProductOption
 * 
 * @property int $id
 * @property int $product_id
 * @property string $name
 * @property string $type
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * 
 * @property Product $product
 * @property Collection|ProductOptionValue[] $product_option_values
 *
 * @package App\Models\Base
 */
class ProductOption extends Model
{
	protected $table = 'product_options';

	protected $casts = [
		'product_id' => 'int'
	];

	public function product()
	{
		return $this->belongsTo(Product::class);
	}

	public function product_option_values()
	{
		return $this->hasMany(ProductOptionValue::class);
	}
}
