<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\Base;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * Class OrderTag
 * 
 * @property int $id
 * @property int $salla_id
 * @property string $name
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 *
 * @package App\Models\Base
 */
class OrderTag extends Model
{
	protected $table = 'order_tags';

	protected $casts = [
		'salla_id' => 'int'
	];
}
