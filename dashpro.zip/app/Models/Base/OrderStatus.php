<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\Base;

use App\Models\Order;
use App\Models\OrderHistory;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;

/**
 * Class OrderStatus
 * 
 * @property int $id
 * @property int $salla_id
 * @property string $name
 * @property string $color
 * @property string $icon
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * 
 * @property Collection|OrderHistory[] $order_histories
 * @property Collection|Order[] $orders
 *
 * @package App\Models\Base
 */
class OrderStatus extends Model
{
	protected $table = 'order_statuses';

	protected $casts = [
		'salla_id' => 'int'
	];

	public function order_histories()
	{
		return $this->hasMany(OrderHistory::class, 'status_id');
	}

	public function orders()
	{
		return $this->hasMany(Order::class, 'status_id');
	}
}
