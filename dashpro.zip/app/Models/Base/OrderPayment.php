<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\Base;

use App\Models\Order;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * Class OrderPayment
 * 
 * @property int $id
 * @property int $order_id
 * @property string $payment_method
 * @property float $amount
 * @property Carbon|null $payment_date
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * 
 * @property Order $order
 *
 * @package App\Models\Base
 */
class OrderPayment extends Model
{
	protected $table = 'order_payments';

	protected $casts = [
		'order_id' => 'int',
		'amount' => 'float',
		'payment_date' => 'datetime'
	];

	public function order()
	{
		return $this->belongsTo(Order::class);
	}
}
