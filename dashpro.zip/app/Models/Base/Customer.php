<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\Base;

use App\Models\CustomerGroupCustomer;
use App\Models\Order;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Customer
 * 
 * @property int $id
 * @property int $salla_id
 * @property int $store_id
 * @property string $first_name
 * @property string $last_name
 * @property int $mobile
 * @property string $mobile_code
 * @property string|null $email
 * @property string|null $avatar
 * @property string|null $gender
 * @property Carbon|null $birthday
 * @property string|null $city
 * @property string|null $country
 * @property string|null $country_code
 * @property string|null $currency
 * @property string|null $location
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * 
 * @property Collection|CustomerGroupCustomer[] $customer_group_customers
 * @property Collection|Order[] $orders
 *
 * @package App\Models\Base
 */
class Customer extends Model
{
	protected $table = 'customers';

	protected $casts = [
		'salla_id' => 'int',
		'store_id' => 'int',
		'mobile' => 'int',
		'birthday' => 'datetime'
	];

	public function customer_group_customers()
	{
		return $this->hasMany(CustomerGroupCustomer::class);
	}

	public function orders()
	{
		return $this->hasMany(Order::class);
	}
}
