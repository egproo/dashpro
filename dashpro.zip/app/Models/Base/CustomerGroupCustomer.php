<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\Base;

use App\Models\Customer;
use App\Models\CustomerGroup;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * Class CustomerGroupCustomer
 * 
 * @property int $id
 * @property int $customer_id
 * @property int $customer_group_id
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * 
 * @property CustomerGroup $customer_group
 * @property Customer $customer
 *
 * @package App\Models\Base
 */
class CustomerGroupCustomer extends Model
{
	protected $table = 'customer_group_customer';

	protected $casts = [
		'customer_id' => 'int',
		'customer_group_id' => 'int'
	];

	public function customer_group()
	{
		return $this->belongsTo(CustomerGroup::class);
	}

	public function customer()
	{
		return $this->belongsTo(Customer::class);
	}
}
