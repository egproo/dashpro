<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\Base;

use App\Models\Category;
use App\Models\EventLog;
use App\Models\Order;
use App\Models\Product;
use App\Models\StoreToken;
use App\Models\TokenHistory;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Store
 * 
 * @property int $id
 * @property int $salla_id
 * @property string|null $code
 * @property string|null $state
 * @property string $name
 * @property string $entity
 * @property string $email
 * @property string|null $avatar
 * @property string $plan
 * @property string $status
 * @property bool $verified
 * @property string $currency
 * @property string $domain
 * @property string|null $description
 * @property array|null $licenses
 * @property array|null $social
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * 
 * @property Collection|Category[] $categories
 * @property Collection|EventLog[] $event_logs
 * @property Collection|Order[] $orders
 * @property Collection|Product[] $products
 * @property Collection|StoreToken[] $store_tokens
 * @property Collection|TokenHistory[] $token_histories
 *
 * @package App\Models\Base
 */
class Store extends Model
{
	protected $table = 'stores';

	protected $casts = [
		'salla_id' => 'int',
		'verified' => 'bool',
		'licenses' => 'json',
		'social' => 'json'
	];

	public function categories()
	{
		return $this->hasMany(Category::class);
	}

	public function event_logs()
	{
		return $this->hasMany(EventLog::class);
	}

	public function orders()
	{
		return $this->hasMany(Order::class);
	}

	public function products()
	{
		return $this->hasMany(Product::class);
	}

	public function store_tokens()
	{
		return $this->hasMany(StoreToken::class);
	}

	public function token_histories()
	{
		return $this->hasMany(TokenHistory::class);
	}
}
