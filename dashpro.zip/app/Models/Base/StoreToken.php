<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\Base;

use App\Models\Store;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * Class StoreToken
 * 
 * @property int $id
 * @property int $store_id
 * @property string $access_token
 * @property string $refresh_token
 * @property int $expires_in
 * @property string $token_type
 * @property string $scope
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * 
 * @property Store $store
 *
 * @package App\Models\Base
 */
class StoreToken extends Model
{
	protected $table = 'store_tokens';

	protected $casts = [
		'store_id' => 'int',
		'expires_in' => 'int'
	];

	public function store()
	{
		return $this->belongsTo(Store::class);
	}
}
