<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\Base;

use App\Models\Category;
use App\Models\OrderItem;
use App\Models\ProductImage;
use App\Models\ProductOption;
use App\Models\ProductVariant;
use App\Models\Store;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Product
 * 
 * @property int $id
 * @property int $salla_id
 * @property int $store_id
 * @property string $name
 * @property string $type
 * @property string|null $sku
 * @property float $price
 * @property float|null $discount_price
 * @property string|null $description
 * @property int $category_id
 * @property int $stock_quantity
 * @property string $status
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * 
 * @property Category $category
 * @property Store $store
 * @property Collection|OrderItem[] $order_items
 * @property Collection|ProductImage[] $product_images
 * @property Collection|ProductOption[] $product_options
 * @property Collection|ProductVariant[] $product_variants
 *
 * @package App\Models\Base
 */
class Product extends Model
{
	protected $table = 'products';

	protected $casts = [
		'salla_id' => 'int',
		'store_id' => 'int',
		'price' => 'float',
		'discount_price' => 'float',
		'category_id' => 'int',
		'stock_quantity' => 'int'
	];

	public function category()
	{
		return $this->belongsTo(Category::class);
	}

	public function store()
	{
		return $this->belongsTo(Store::class);
	}

	public function order_items()
	{
		return $this->hasMany(OrderItem::class);
	}

	public function product_images()
	{
		return $this->hasMany(ProductImage::class);
	}

	public function product_options()
	{
		return $this->hasMany(ProductOption::class);
	}

	public function product_variants()
	{
		return $this->hasMany(ProductVariant::class);
	}
}
