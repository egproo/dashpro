<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\Base;

use App\Models\Customer;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;

/**
 * Class CustomerGroup
 * 
 * @property int $id
 * @property int $salla_id
 * @property int $store_id
 * @property string $name
 * @property array|null $conditions
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * 
 * @property Collection|Customer[] $customers
 *
 * @package App\Models\Base
 */
class CustomerGroup extends Model
{
	protected $table = 'customer_groups';

	protected $casts = [
		'salla_id' => 'int',
		'store_id' => 'int',
		'conditions' => 'json'
	];

	public function customers()
	{
		return $this->belongsToMany(Customer::class, 'customer_group_customer')
					->withPivot('id')
					->withTimestamps();
	}
}
