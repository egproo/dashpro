<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\Base;

use App\Models\Product;
use App\Models\Store;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Category
 * 
 * @property int $id
 * @property int $salla_id
 * @property int $store_id
 * @property string $name
 * @property string|null $description
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * 
 * @property Store $store
 * @property Collection|Product[] $products
 *
 * @package App\Models\Base
 */
class Category extends Model
{
	protected $table = 'categories';

	protected $casts = [
		'salla_id' => 'int',
		'store_id' => 'int'
	];

	public function store()
	{
		return $this->belongsTo(Store::class);
	}

	public function products()
	{
		return $this->hasMany(Product::class);
	}
}
