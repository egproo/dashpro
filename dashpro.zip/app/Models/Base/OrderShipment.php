<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\Base;

use App\Models\Order;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * Class OrderShipment
 * 
 * @property int $id
 * @property int $order_id
 * @property string $shipment_method
 * @property string|null $tracking_number
 * @property Carbon|null $shipment_date
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * 
 * @property Order $order
 *
 * @package App\Models\Base
 */
class OrderShipment extends Model
{
	protected $table = 'order_shipments';

	protected $casts = [
		'order_id' => 'int',
		'shipment_date' => 'datetime'
	];

	public function order()
	{
		return $this->belongsTo(Order::class);
	}
}
