<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\Base;

use App\Models\Product;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * Class ProductVariant
 * 
 * @property int $id
 * @property int $product_id
 * @property string $name
 * @property string|null $sku
 * @property float $price
 * @property float|null $discount_price
 * @property int $stock_quantity
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * 
 * @property Product $product
 *
 * @package App\Models\Base
 */
class ProductVariant extends Model
{
	protected $table = 'product_variants';

	protected $casts = [
		'product_id' => 'int',
		'price' => 'float',
		'discount_price' => 'float',
		'stock_quantity' => 'int'
	];

	public function product()
	{
		return $this->belongsTo(Product::class);
	}
}
