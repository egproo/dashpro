<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\Base;

use App\Models\ProductOption;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * Class ProductOptionValue
 * 
 * @property int $id
 * @property int $product_option_id
 * @property string $name
 * @property float|null $price
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * 
 * @property ProductOption $product_option
 *
 * @package App\Models\Base
 */
class ProductOptionValue extends Model
{
	protected $table = 'product_option_values';

	protected $casts = [
		'product_option_id' => 'int',
		'price' => 'float'
	];

	public function product_option()
	{
		return $this->belongsTo(ProductOption::class);
	}
}
