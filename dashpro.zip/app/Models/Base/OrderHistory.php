<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\Base;

use App\Models\Order;
use App\Models\OrderStatus;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * Class OrderHistory
 * 
 * @property int $id
 * @property int $order_id
 * @property int $status_id
 * @property string|null $comment
 * @property Carbon $changed_at
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * 
 * @property Order $order
 * @property OrderStatus $order_status
 *
 * @package App\Models\Base
 */
class OrderHistory extends Model
{
	protected $table = 'order_history';

	protected $casts = [
		'order_id' => 'int',
		'status_id' => 'int',
		'changed_at' => 'datetime'
	];

	public function order()
	{
		return $this->belongsTo(Order::class);
	}

	public function order_status()
	{
		return $this->belongsTo(OrderStatus::class, 'status_id');
	}
}
