<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\Base;

use App\Models\Store;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * Class EventLog
 * 
 * @property int $id
 * @property int $store_id
 * @property string $event_name
 * @property array $event_data
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * 
 * @property Store $store
 *
 * @package App\Models\Base
 */
class EventLog extends Model
{
	protected $table = 'event_logs';

	protected $casts = [
		'store_id' => 'int',
		'event_data' => 'json'
	];

	public function store()
	{
		return $this->belongsTo(Store::class);
	}
}
