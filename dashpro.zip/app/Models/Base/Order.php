<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\Base;

use App\Models\Customer;
use App\Models\OrderHistory;
use App\Models\OrderItem;
use App\Models\OrderPayment;
use App\Models\OrderShipment;
use App\Models\OrderStatus;
use App\Models\Store;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Order
 * 
 * @property int $id
 * @property int $salla_id
 * @property int $store_id
 * @property int $customer_id
 * @property int $status_id
 * @property float $total_price
 * @property float $shipping_cost
 * @property string $payment_method
 * @property string $shipping_method
 * @property Carbon|null $order_date
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * 
 * @property Customer $customer
 * @property OrderStatus $order_status
 * @property Store $store
 * @property Collection|OrderHistory[] $order_histories
 * @property Collection|OrderItem[] $order_items
 * @property Collection|OrderPayment[] $order_payments
 * @property Collection|OrderShipment[] $order_shipments
 *
 * @package App\Models\Base
 */
class Order extends Model
{
	protected $table = 'orders';

	protected $casts = [
		'salla_id' => 'int',
		'store_id' => 'int',
		'customer_id' => 'int',
		'status_id' => 'int',
		'total_price' => 'float',
		'shipping_cost' => 'float',
		'order_date' => 'datetime'
	];

	public function customer()
	{
		return $this->belongsTo(Customer::class);
	}

	public function order_status()
	{
		return $this->belongsTo(OrderStatus::class, 'status_id');
	}

	public function store()
	{
		return $this->belongsTo(Store::class);
	}

	public function order_histories()
	{
		return $this->hasMany(OrderHistory::class);
	}

	public function order_items()
	{
		return $this->hasMany(OrderItem::class);
	}

	public function order_payments()
	{
		return $this->hasMany(OrderPayment::class);
	}

	public function order_shipments()
	{
		return $this->hasMany(OrderShipment::class);
	}
}
