<?php

namespace App\Models;

use App\Models\Base\ProductOption as BaseProductOption;

class ProductOption extends BaseProductOption
{
	protected $fillable = [
		'product_id',
		'name',
		'type'
	];
}
