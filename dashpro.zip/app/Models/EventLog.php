<?php

namespace App\Models;

use App\Models\Base\EventLog as BaseEventLog;

class EventLog extends BaseEventLog
{
	protected $fillable = [
		'store_id',
		'event_name',
		'event_data'
	];
}
