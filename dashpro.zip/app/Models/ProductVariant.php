<?php

namespace App\Models;

use App\Models\Base\ProductVariant as BaseProductVariant;

class ProductVariant extends BaseProductVariant
{
	protected $fillable = [
		'product_id',
		'name',
		'sku',
		'price',
		'discount_price',
		'stock_quantity'
	];
}
