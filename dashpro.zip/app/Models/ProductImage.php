<?php

namespace App\Models;

use App\Models\Base\ProductImage as BaseProductImage;

class ProductImage extends BaseProductImage
{
	protected $fillable = [
		'product_id',
		'image_path',
		'alt_text'
	];
}
