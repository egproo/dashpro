<?php

namespace App\Models;

use App\Models\Base\OrderStatus as BaseOrderStatus;

class OrderStatus extends BaseOrderStatus
{
	protected $fillable = [
		'salla_id',
		'name',
		'color',
		'icon'
	];
}
