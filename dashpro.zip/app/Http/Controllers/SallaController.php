<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\ProductOption;
use App\Models\ProductOptionValue;
use App\Models\ProductImage;
use App\Models\User;
use App\Models\Notification;
use App\Models\Store;
use App\Models\StoreToken;
use App\Models\TokenHistory;
use App\Models\Category;
use App\Models\Order;
use App\Models\OrderHistory;
use App\Models\OrderItem;
use App\Models\OrderPayment;
use App\Models\OrderShipment;
use App\Models\OrderStatus;
use App\Models\OrderTag;
use App\Models\Customer;
use App\Models\EventLog;
use App\Models\CustomerGroup;
class SallaController extends Controller
{
    private $clientId;
    private $clientSecret;
    private $tokenUrl = 'https://accounts.salla.sa/oauth2/token';

    public function __construct()
    {
        $this->clientId = '52460b65-427d-4e6e-bc6a-226089176dca';
        $this->clientSecret = '125087748bad410df30345ae6f21f41b';
    }

public function customers()
{
    $storeTokens = StoreToken::all();

    foreach ($storeTokens as $storeToken) {
        $headers = [
            'Authorization: Bearer ' . $storeToken->access_token,
            'Accept: application/json'
        ];

        // جلب مجموعات العملاء
        $groupsResponse = $this->sendCurlRequest("https://api.salla.dev/admin/v2/customers/groups", [], $headers, "GET");
        $groupsData = json_decode($groupsResponse, true);
		print_r($groupsData);
        if (isset($groupsData['data'])) {
            foreach ($groupsData['data'] as $groupData) {
                $group = CustomerGroup::updateOrCreate(
                    ['salla_id' => $groupData['id'], 'store_id' => $storeToken->store_id],
                    ['name' => $groupData['name']]
                );
            }
        }

        // جلب العملاء
        $customersResponse = $this->sendCurlRequest("https://api.salla.dev/admin/v2/customers", [], $headers, "GET");
        $customersData = json_decode($customersResponse, true);

        if (isset($customersData['data'])) {
            foreach ($customersData['data'] as $customerData) {
                $customer = Customer::updateOrCreate(
                    ['salla_id' => $customerData['id'], 'store_id' => $storeToken->store_id],
                    [
                        'first_name' => $customerData['first_name'],
                        'last_name' => $customerData['last_name'],
                        'mobile' => $customerData['mobile'],
                        'mobile_code' => $customerData['mobile_code'],
                        'email' => $customerData['email'],
                        'avatar' => $customerData['avatar'],
                        'gender' => $customerData['gender'],
                        'city' => $customerData['city'],
                        'country' => $customerData['country']
                    ]
                );

                // ربط العميل بمجموعاته
                $groupIds = CustomerGroup::whereIn('salla_id', $customerData['groups'])->where('store_id', $storeToken->store_id)->pluck('id')->toArray();
                $customer->groups()->sync($groupIds);
            }
        }
    }
}


public function products()
{
    $storeTokens = StoreToken::all();

    foreach ($storeTokens as $storeToken) {
        $headers = [
            'Authorization: Bearer ' . $storeToken->access_token,
            'Accept: application/json'
        ];

        $productsResponse = $this->sendCurlRequest("https://api.salla.dev/admin/v2/products", [], $headers, "GET");
        $productsData = json_decode($productsResponse, true);

        if (isset($productsData['data'])) {
            foreach ($productsData['data'] as $productData) {
                $product = Product::where('salla_id', $productData['id'])->where('store_id', $storeToken->store_id)->first();

                if (!$product) {
                    $product = new Product();
                    $product->salla_id = $productData['id'];
                    $product->store_id = $storeToken->store_id;
                }

                // تحديث البيانات المنتج هنا
                $product->name = $productData['name'];
                $product->type = $productData['type'];
                $product->sku = $productData['sku'];
                $product->price = $productData['price'];
                $product->discount_price = $productData['discount_price'];
                $product->description = $productData['description'];
                $product->category_id = $productData['category_id'];
                $product->stock_quantity = $productData['stock_quantity'];
                $product->status = $productData['status'];

                $product->save();

                // إضافة الإصدارات المختلفة للمنتج
                foreach ($productData['variants'] as $variantData) {
                    $variant = ProductVariant::where('product_id', $product->id)->first();

                    if (!$variant) {
                        $variant = new ProductVariant();
                        $variant->product_id = $product->id;
                    }

                    $variant->name = $variantData['name'];
                    $variant->sku = $variantData['sku'];
                    $variant->price = $variantData['price'];
                    $variant->discount_price = $variantData['discount_price'];
                    $variant->stock_quantity = $variantData['stock_quantity'];

                    $variant->save();
                }

                // إضافة خيارات المنتج
                foreach ($productData['options'] as $optionData) {
                    $option = ProductOption::where('product_id', $product->id)->first();

                    if (!$option) {
                        $option = new ProductOption();
                        $option->product_id = $product->id;
                    }

                    $option->name = $optionData['name'];
                    $option->type = $optionData['type'];

                    $option->save();

                    // إضافة قيم خيارات المنتج
                    foreach ($optionData['values'] as $valueData) {
                        $value = ProductOptionValue::where('product_option_id', $option->id)->first();

                        if (!$value) {
                            $value = new ProductOptionValue();
                            $value->product_option_id = $option->id;
                        }

                        $value->name = $valueData['name'];
                        $value->price = $valueData['price'];

                        $value->save();
                    }
                }

                // إضافة صور المنتج
                foreach ($productData['images'] as $imageData) {
                    $image = ProductImage::where('product_id', $product->id)->first();

                    if (!$image) {
                        $image = new ProductImage();
                        $image->product_id = $product->id;
                    }

                    $image->image_path = $imageData['image_path'];
                    $image->alt_text = $imageData['alt_text'];

                    $image->save();
                }
            }
        }
    }
}

public function refreshtoken()
{
    // جلب جميع التوكنات من جدول store_tokens
    $storeTokens = DB::table('store_tokens')->get();

    foreach ($storeTokens as $storeToken) {
        $headers = [
            "Content-Type: application/x-www-form-urlencoded",
            "Authorization: Bearer " . $storeToken->access_token,
			'Accept: application/json'
        ];

		$credi = [
            'client_id' => $this->clientId,
            'client_secret' => $this->clientSecret,
            'grant_type' => 'refresh_token',
            'refresh_token' => $storeToken->refresh_token,
            'redirect_uri' => 'https://portal.egproo.com/callback'
        ];
		print_r($credi);

        $response = $this->sendCurlRequest($this->tokenUrl, $credi, $headers);
        $json_response = json_decode($response, true);

        // التحقق من وجود المفتاح "access_token" في الرد
        if (isset($json_response['access_token'])) {
            // تحديث التوكن في جدول store_tokens
            DB::table('store_tokens')->where('store_id', $storeToken->store_id)->update([
                'access_token' => $json_response['access_token'],
                'refresh_token' => $json_response['refresh_token'],
                'expires_in' => $json_response['expires_in'],
                'updated_at' => now()
            ]);

            // إضافة سجل في جدول token_history
            DB::table('token_history')->insert([
                'store_id' => $storeToken->store_id,
                'access_token' => $json_response['access_token'],
                'refresh_token' => $json_response['refresh_token'],
                'created_at' => now(),
                'updated_at' => now()
            ]);
        } else {
            echo $response;
        }
    }
}
public function token()
{
    // جلب جميع المتاجر من جدول stores
    $stores = DB::table('stores')->get();

    foreach ($stores as $store) {
        if (!isset($store->code)) {
            echo "لم يتم العثور على الـ code للمتجر بالمعرف: " . $store->id;
            continue;
        }

        $code = $store->code;
        $state = $store->state;
        $headers = [
            "Content-Type: application/x-www-form-urlencoded",
			
        ];
		$credi = [
            'client_id' => $this->clientId,
            'client_secret' => $this->clientSecret,
            'grant_type' => 'authorization_code',
            'code' => $code,
				'scope' => 'offline_access',
            'state' => $state,
            'redirect_uri' => 'https://portal.egproo.com/callback'
        ];
		print_r($credi);

        $response = $this->sendCurlRequest($this->tokenUrl, $credi, $headers);
        $json_response = json_decode($response, true);

        if (isset($json_response['access_token'])) {
            // تحديث التوكن في جدول store_tokens
            DB::table('store_tokens')->where('store_id', $store->id)->update([
                'access_token' => $json_response['access_token'],
                'refresh_token' => $json_response['refresh_token'],
                'expires_in' => $json_response['expires_in'],
                'updated_at' => now()
            ]);

            // إضافة سجل جديد في جدول token_history
            DB::table('token_history')->insert([
                'store_id' => $store->id,
                'access_token' => $json_response['access_token'],
                'refresh_token' => $json_response['refresh_token'],
                'created_at' => now(),
                'updated_at' => now()
            ]);
        } else {
            // يمكنك التعامل مع الأخطاء هنا إذا لم يتم الحصول على الـ access_token
            echo "رد الخادم للمتجر بالمعرف " . $store->id . ": " . $response;
        }
    }
}
public function statuslist(){
//for store 2 only direct for test
$curl = curl_init();

curl_setopt_array($curl, [
  CURLOPT_URL => "https://api.salla.dev/admin/v2/orders/statuses",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_HTTPHEADER => [
    "Accept: application/json",
    "Authorization: Bearer ory_at_6KCPc_KSXwij6g4pyGw5zIEKnhEDbbumEPlEjZzIFwE.n4v_ZP8GIdPuO2LC_AdnbYFJLVpyzp6auAjQq7D2Ox8"
  ],
]);

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  echo $response;
}	
}
public function storii()
{
    // جلب جميع المتاجر من جدول store_tokens
    $storeTokens = DB::table('store_tokens')->get();

    $allStoresData = [];

    foreach ($storeTokens as $storeToken) {
        $headers = [
            'Authorization: Bearer ' . $storeToken->access_token,
            'Accept: application/json'
        ];

        $storeResponse = $this->sendCurlRequest("https://api.salla.dev/admin/v2/store/info", [], $headers, "GET");
        $storeData = json_decode($storeResponse, true);

        if (isset($storeData['data'])) {
            $allStoresData[] = $storeData['data'];
        } else {
            // يمكنك إضافة رسالة خطأ هنا إذا كنت ترغب في معرفة المتاجر التي لم يتم جلب بياناتها بنجاح
            $allStoresData[] = ['error' => 'حدث خطأ أثناء الحصول على بيانات المتجر بالمعرف: ' . $storeToken->store_id];
        }
    }

    return response()->json($allStoresData);
}



			// Method to handle the OAuth callback
		public function callback(Request $request)
		{
			$postData = [
				'client_id' => $this->clientId,
				'client_secret' => $this->clientSecret,
				'grant_type' => 'authorization_code',
            'code' => $request->code,
				'scope' => 'offline_access',
            'state' => $request->state,
				'redirect_uri' => 'https://portal.egproo.com/callback'
			];

			$response = $this->sendCurlRequest($this->tokenUrl, $postData, ["Content-Type: application/x-www-form-urlencoded"]);
			$json_response = json_decode($response, true);

			$storeResponse = $this->sendCurlRequest("https://api.salla.dev/admin/v2/store/info", [], [
				'Authorization: Bearer ' . $json_response['access_token'],
				'Accept: application/json'
			], "GET");
			$storeData = json_decode($storeResponse, true);

			// حفظ بيانات المتجر في جدول stores واحصل على المعرف الجديد
			$storeId = DB::table('stores')->insertGetId([
				'salla_id' => $storeData['data']['id'],
				'name' => $storeData['data']['name'],
				'entity' => $storeData['data']['entity'],
				'code' => $request->code,
				'state' => $request->state,
				'email' => $storeData['data']['email'],
				'avatar' => $storeData['data']['avatar'],
				'plan' => $storeData['data']['plan'],
				'status' => $storeData['data']['status'],
				'verified' => $storeData['data']['verified'],
				'currency' => $storeData['data']['currency'],
				'domain' => $storeData['data']['domain'],
				'description' => $storeData['data']['description'],
				'licenses' => json_encode($storeData['data']['licenses']),
				'social' => json_encode($storeData['data']['social']),
				'created_at' => now(),
				'updated_at' => now()
			]);

			// حفظ بيانات التوكن في جدول store_tokens
			DB::table('store_tokens')->insert([
				'store_id' => $storeId,
				'access_token' => $json_response['access_token'],
				'refresh_token' => $json_response['refresh_token'],
				'expires_in' => $json_response['expires_in'],
				'token_type' => $json_response['token_type'],
				'scope' => $json_response['scope'],
				'created_at' => now(),
				'updated_at' => now()
			]);
			

			// يمكنك إرجاع الرد أو توجيه المستخدم حسب الحاجة
			//return redirect('/');
		}

		public function saveCategories($categoriesData, $storeId, $parentId = null) {
			foreach ($categoriesData as $categoryData) {
				// تحقق من وجود القسم بالفعل باستخدام المعرف ومعرف المتجر
				$category = Category::where('id', $categoryData['id'])->where('store_id', $storeId)->first();

				if (!$category) {
					$category = new Category();
					$category->id = $categoryData['id'];
					$category->store_id = $storeId;
				}

				$category->name = $categoryData['name'];
				$category->sort_order = $categoryData['sort_order'];
				$category->parent_id = $parentId;
				$category->status = 'active'; // يمكن تعديل هذا القيمة حسب الحاجة
				$category->save();

				// إذا كانت هناك أقسام فرعية، قم بحفظها باستدعاء الدالة نفسها
				if (!empty($categoryData['items'])) {
					$this->saveCategories($categoryData['items'], $storeId, $category->id);
				}
			}
		}


    // Helper method to send cURL requests
	private function sendCurlRequest($url, $postFields = [], $headers = [], $method = "POST")
{
    $curl = curl_init();

    // Check if the content type is application/x-www-form-urlencoded
    if (in_array("Content-Type: application/x-www-form-urlencoded", $headers)) {
        $postData = http_build_query($postFields);
    } else {
        $postData = json_encode($postFields);
        $headers = array_merge(["Content-Type: application/json"], $headers);
    }

    curl_setopt_array($curl, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_POSTFIELDS => $postData,
        CURLOPT_HTTPHEADER => $headers,
    ]);

    $response = curl_exec($curl);
    $err = curl_error($curl);

    curl_close($curl);

    if ($err) {
        echo "cURL Error #:" . $err;
        return null;
    } else {
        return $response;
    }
}
public function events()
{
    $storeTokens = StoreToken::all();
    $allEvents = [];

    foreach ($storeTokens as $storeToken) {
        $headers = [
            'Authorization: Bearer ' . $storeToken->access_token,
            'Accept: application/json'
        ];

        $response = $this->sendCurlRequest("https://api.salla.dev/admin/v2/webhooks/events", [], $headers, "GET");
        $responseData = json_decode($response, true);

        if (isset($responseData['data'])) {
            $storeEvents = [
                'store_id' => $storeToken->store_id,
                'events' => $responseData['data']
            ];
            $allEvents[] = $storeEvents;
        }
    }

    return response()->json($allEvents);
}

public function updates(Request $request)
{
    $eventData = $request->all();

    if (!isset($eventData['event'])) {
        return response()->json(['message' => 'Invalid event data'], 400);
    }

    $store = Store::where('salla_id', $eventData['merchant'])->first();
    if (!$store) {
        return response()->json(['message' => 'Store not found'], 404);
    }

    // Log the event
    $eventLog = new EventLog();
    $eventLog->store_id = $store->id;
    $eventLog->event_name = $eventData['event'];
    $eventLog->event_data = json_encode($eventData);
    $eventLog->save();

    switch ($eventData['event']) {
        case 'customer.created':
        case 'customer.updated':
            $customerData = $eventData['data'];
            $customer = Customer::where('salla_id', $customerData['id'])->where('store_id', $store->id)->first();

            if (!$customer) {
                $customer = new Customer();
                $customer->salla_id = $customerData['id'];
                $customer->store_id = $store->id;
            }

            $customer->first_name = $customerData['first_name'];
            $customer->last_name = $customerData['last_name'];
            $customer->mobile = $customerData['mobile'];
            $customer->mobile_code = $customerData['mobile_code'];
            $customer->email = $customerData['email'];
            $customer->avatar = $customerData['avatar'];
            $customer->gender = $customerData['gender'];
            $customer->city = $customerData['city'];
            $customer->country = $customerData['country'];
            $customer->save();
            break;
        case 'product.created':
			$productData = $eventData['data'];
			$product = new Product();
			$product->salla_id = $productData['id'];
			$product->store_id = $store->id;
			$product->name = $productData['name'];
			$product->sku = $productData['sku'] ?? null; // استخدام null كقيمة افتراضية إذا لم يتم توفير sku
			$product->price = $productData['price']['amount'];
			$product->currency = $productData['price']['currency'];
			$product->description = $productData['description'] ?? null; // استخدام null كقيمة افتراضية إذا لم يتم توفير الوصف
			$product->status = $productData['status'];
			$product->url = $productData['url'];
			$product->main_image = $productData['main_image'] ?? null; // استخدام null كقيمة افتراضية إذا لم يتم توفير الصورة الرئيسية
			// يمكنك إضافة المزيد من الحقول هنا حسب بيانات المنتج التي تحصل عليها من الحدث
			$product->save();

			// إذا كان لديك جدول خاص بالتصنيفات، يمكنك أيضًا تخزين التصنيفات المرتبطة بالمنتج هنا
			foreach ($productData['categories'] as $categoryData) {
				$category = Category::firstOrCreate(['salla_id' => $categoryData['id']], [
					'name' => $categoryData['name'],
					// يمكنك إضافة المزيد من الحقول هنا حسب بيانات التصنيف
				]);
				$product->categories()->attach($category->id); // ربط المنتج بالتصنيف
			}

        break;			

        // باقي الحالات
        default:
            return response()->json(['message' => 'Event not handled'], 400);
    }

    return response()->json(['message' => 'done']);
}


    // Other methods remain unchanged...
}
